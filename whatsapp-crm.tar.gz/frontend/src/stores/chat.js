import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import api from '../utils/api.js';
import { useSocket } from '../utils/socket.js';

export const useChatStore = defineStore('chat', () => {
  // WhatsApp Connection
  const connectionStatus = ref('disconnected'); // disconnected | connecting | waiting_qr | connected | reconnecting
  const sessionId = ref(null);
  const connectedPhone = ref(null);
  const qrCode = ref(null);
  const waError = ref(null);

  // Conversations
  const conversations = ref([]);
  const activeJid = ref(null);

  // Messages
  const messages = ref({});
  const loadingMessages = ref(false);

  // Translation
  const translationSettings = ref({
    translationEnabled: true,
    translationEngine: 'doubao',
    targetLanguage: 'zh',
    doubaoApiKey: '',
    deepseekApiKey: '',
  });
  const autoTranslateOutgoing = ref(true);

  // AI Reply
  const aiReplies = ref([]);
  const aiGenerating = ref(false);
  const insertText = ref('');

  // AI Summarize
  const needSummary = ref(null);
  const summarizeLoading = ref(false);

  // Computed
  const activeConversation = computed(() =>
    conversations.value.find(c => c.jid === activeJid.value)
  );

  const currentMessages = computed(() => {
    if (!activeJid.value) return [];
    return messages.value[activeJid.value] || [];
  });

  const sortedConversations = computed(() => {
    return [...conversations.value].sort((a, b) => {
      const tA = a.lastMessageTime ? new Date(a.lastMessageTime).getTime() : 0;
      const tB = b.lastMessageTime ? new Date(b.lastMessageTime).getTime() : 0;
      return tB - tA;
    });
  });

  const isConnected = computed(() => connectionStatus.value === 'connected');

  // ─── WhatsApp Connection Actions ───

  async function fetchConnectionStatus() {
    try {
      const { data } = await api.get('/whatsapp/status');
      connectionStatus.value = data.status;
      sessionId.value = data.sessionId;
      connectedPhone.value = data.phone || null;
      if (data.status === 'connected') {
        qrCode.value = null;
      }
      return data;
    } catch (err) {
      console.error('Failed to fetch connection status:', err);
      return null;
    }
  }

  async function requestQR() {
    try {
      qrCode.value = null;
      connectionStatus.value = 'connecting';
      waError.value = null;
      const { data } = await api.post('/whatsapp/qr');
      sessionId.value = data.sessionId;
      // QR comes asynchronously via Socket.io (whatsapp:qr event)
      // But also check if it was returned directly
      if (data.qr) {
        qrCode.value = { qr: data.qr, sessionId: data.sessionId };
      }
      if (data.status === 'connected') {
        connectionStatus.value = 'connected';
        connectedPhone.value = data.phone;
        qrCode.value = null;
      }
      if (data.status === 'unavailable') {
        connectionStatus.value = 'unavailable';
        waError.value = data.message || 'WhatsApp 库未安装';
      }
      return data;
    } catch (err) {
      console.error('Failed to request QR:', err);
      connectionStatus.value = 'disconnected';
      const msg = err.response?.data?.error || err.message || '连接失败';
      waError.value = msg;
      return null;
    }
  }

  async function disconnectWhatsApp() {
    try {
      await api.post('/whatsapp/disconnect');
      connectionStatus.value = 'disconnected';
      connectedPhone.value = null;
      qrCode.value = null;
      sessionId.value = null;
    } catch (err) {
      console.error('Failed to disconnect:', err);
    }
  }

  // ─── Conversations Actions ───

  async function fetchConversations() {
    try {
      const { data } = await api.get('/whatsapp/conversations');
      conversations.value = data;
    } catch (err) {
      console.error('Failed to fetch conversations:', err);
    }
  }

  async function fetchMessages(jid, limit = 50) {
    if (!jid) return;
    loadingMessages.value = true;
    try {
      const { data } = await api.get('/whatsapp/messages', {
        params: { jid, limit },
      });
      // Normalize messages for display
      messages.value[jid] = data.map(msg => normalizeMessage(msg));
    } catch (err) {
      console.error('Failed to fetch messages:', err);
    } finally {
      loadingMessages.value = false;
    }
  }

  function normalizeMessage(msg) {
    // Handle both WAMessage format and socket event format
    const fromJid = msg.direction === 'inbound' || msg.direction === 'incoming'
      ? msg.from
      : msg.to;
    return {
      id: msg.id || msg.waMessageId || Date.now(),
      jid: msg.jid || fromJid,
      from: msg.from,
      to: msg.to,
      content: msg.body || msg.content || '',
      body: msg.body || msg.content || '',
      fromMe: msg.direction === 'outbound' || msg.direction === 'outgoing' || msg.fromMe === true,
      direction: msg.direction,
      messageType: msg.type || msg.messageType || 'text',
      timestamp: msg.timestamp,
      translation: msg.translation || null,
      sourceLang: msg.sourceLang || null,
    };
  }

  function sendMessage(jid, text) {
    const socket = useSocket();
    socket.emit('whatsapp:send_message', {
      to: jid,
      message: text,
      autoTranslate: autoTranslateOutgoing.value && translationSettings.value.translationEnabled,
    });
  }

  function setActiveConversation(jid) {
    activeJid.value = jid;
    // Clear AI state when switching conversation
    aiReplies.value = [];
    needSummary.value = null;
    if (jid) {
      // Mark as read
      const socket = useSocket();
      socket.emit('whatsapp:mark_read', { jid });
      // Clear unread count locally
      const conv = conversations.value.find(c => c.jid === jid);
      if (conv) conv.unreadCount = 0;
      // Fetch messages
      fetchMessages(jid);
    }
  }

  // ─── Socket Event Handlers ───

  function handleQRCode(data) {
    qrCode.value = data;
    connectionStatus.value = 'waiting_qr';
    waError.value = null;
  }

  function handleWAError(data) {
    connectionStatus.value = 'error';
    qrCode.value = null;
    waError.value = data.message || '未知错误';
  }

  function handleStatus(data) {
    if (data.status === 'connected') {
      connectionStatus.value = 'connected';
      connectedPhone.value = data.phone || null;
      qrCode.value = null;
      waError.value = null;
      // Fetch conversations when connected
      fetchConversations();
    } else if (data.status === 'disconnected') {
      connectionStatus.value = 'disconnected';
      connectedPhone.value = null;
    } else if (data.status === 'error') {
      connectionStatus.value = 'error';
      qrCode.value = null;
    } else if (data.status === 'connecting' || data.status === 'waiting_qr' || data.status === 'reconnecting') {
      connectionStatus.value = data.status;
    }
  }

  function handleNewMessage(data) {
    const msg = normalizeMessage(data);
    const jid = msg.jid || (msg.fromMe ? msg.to : msg.from);

    if (!jid) return;

    // Add to messages
    if (!messages.value[jid]) {
      messages.value[jid] = [];
    }
    // Avoid duplicates
    const exists = messages.value[jid].find(m => m.id === msg.id);
    if (!exists) {
      messages.value[jid].push(msg);
    }

    // Update or create conversation
    const conv = conversations.value.find(c => c.jid === jid);
    if (conv) {
      conv.lastMessage = msg.content?.substring(0, 100) || '';
      conv.lastMessageTime = msg.timestamp;
      if (!msg.fromMe) {
        conv.unreadCount = (conv.unreadCount || 0) + 1;
      }
    } else {
      const phone = jid.split('@')[0];
      conversations.value.unshift({
        jid,
        name: data.contact?.name || phone,
        phone,
        lastMessage: msg.content?.substring(0, 100) || '',
        lastMessageTime: msg.timestamp,
        unreadCount: msg.fromMe ? 0 : 1,
      });
    }
  }

  function handleMessageSent(data) {
    const msg = normalizeMessage(data);
    const jid = msg.jid || msg.to;
    if (!jid) return;

    if (!messages.value[jid]) {
      messages.value[jid] = [];
    }
    // Avoid duplicates
    const exists = messages.value[jid].find(m => m.id === msg.id);
    if (!exists) {
      messages.value[jid].push(msg);
    }

    // Update conversation
    const conv = conversations.value.find(c => c.jid === jid);
    if (conv) {
      conv.lastMessage = (msg.translation?.original || msg.content)?.substring(0, 100);
      conv.lastMessageTime = msg.timestamp;
    }
  }

  function handleConversations(data) {
    if (Array.isArray(data)) {
      conversations.value = data;
    } else if (data?.conversations) {
      conversations.value = data.conversations;
    }
  }

  function handleMessages(data) {
    if (data?.jid) {
      messages.value[data.jid] = (data.messages || []).map(m => normalizeMessage(m));
    }
  }

  // ─── Settings Actions ───

  async function fetchTranslationSettings() {
    try {
      const { data } = await api.get('/settings');
      const settingsMap = {};
      if (Array.isArray(data)) {
        data.forEach(s => { settingsMap[s.key] = s.value; });
      } else {
        Object.assign(settingsMap, data);
      }
      translationSettings.value = {
        translationEnabled: settingsMap.translationEnabled !== 'false',
        translationEngine: settingsMap.translationEngine || 'doubao',
        targetLanguage: settingsMap.targetLanguage || settingsMap.translationTargetLang || 'zh',
        doubaoApiKey: settingsMap.doubaoApiKey || '',
        deepseekApiKey: settingsMap.deepseekApiKey || '',
        aiModel: settingsMap.aiModel || 'doubao-seed-2-0-pro-260215',
        aiApiEndpoint: settingsMap.aiApiEndpoint || '',
      };
    } catch (err) {
      console.error('Failed to fetch translation settings:', err);
    }
  }

  async function updateTranslationSettings(settings) {
    try {
      const entries = Object.entries(settings).map(([key, value]) => ({
        key,
        value: String(value),
      }));
      await api.put('/settings', { settings: entries });
      translationSettings.value = { ...translationSettings.value, ...settings };
    } catch (err) {
      console.error('Failed to update translation settings:', err);
    }
  }

  // ─── AI Actions ───

  async function translateMessage(text, sourceLang, targetLang) {
    try {
      const { data } = await api.post('/ai/translate', {
        text,
        sourceLang: sourceLang || 'auto',
        targetLang: targetLang || 'zh',
      });
      return data;
    } catch (err) {
      // Fallback to old translation endpoint
      try {
        const { data } = await api.post('/translation/translate', {
          text,
          sourceLang: sourceLang || 'auto',
          targetLang: targetLang || 'zh',
        });
        return data;
      } catch (err2) {
        console.error('Failed to translate message:', err2);
        return null;
      }
    }
  }

  async function generateAIReply(accountId, jid, style = 'formal') {
    if (!jid) return;
    aiGenerating.value = true;
    aiReplies.value = [];
    try {
      const { data } = await api.post('/ai/reply', {
        accountId,
        jid,
        style,
      });
      if (data.replies) {
        aiReplies.value = data.replies.map((text, index) => ({
          id: index,
          text,
          feedback: null,
        }));
      } else if (data.error) {
        console.error('AI reply error:', data.error);
      }
    } catch (err) {
      console.error('Failed to generate AI reply:', err);
    } finally {
      aiGenerating.value = false;
    }
  }

  function insertToInput(text) {
    insertText.value = text;
  }

  function clearInsertText() {
    insertText.value = '';
  }

  async function generateNeedSummary(accountId, jid) {
    if (!jid) return;
    summarizeLoading.value = true;
    needSummary.value = null;
    try {
      const { data } = await api.post('/ai/summarize', {
        accountId,
        jid,
      });
      if (data.summary) {
        needSummary.value = data.summary;
      } else if (data.error) {
        console.error('AI summarize error:', data.error);
      }
    } catch (err) {
      console.error('Failed to generate need summary:', err);
    } finally {
      summarizeLoading.value = false;
    }
  }

  function clearNeedSummary() {
    needSummary.value = null;
  }

  return {
    // State
    connectionStatus,
    sessionId,
    connectedPhone,
    qrCode,
    waError,
    conversations,
    activeJid,
    messages,
    loadingMessages,
    translationSettings,
    autoTranslateOutgoing,
    aiReplies,
    aiGenerating,
    insertText,
    needSummary,
    summarizeLoading,

    // Computed
    activeConversation,
    currentMessages,
    sortedConversations,
    isConnected,

    // WhatsApp Connection
    fetchConnectionStatus,
    requestQR,
    disconnectWhatsApp,

    // Conversations & Messages
    fetchConversations,
    fetchMessages,
    sendMessage,
    setActiveConversation,

    // Socket Handlers
    handleQRCode,
    handleStatus,
    handleWAError,
    handleNewMessage,
    handleMessageSent,
    handleConversations,
    handleMessages,

    // Settings
    fetchTranslationSettings,
    updateTranslationSettings,

    // AI
    translateMessage,
    generateAIReply,
    insertToInput,
    clearInsertText,
    generateNeedSummary,
    clearNeedSummary,
  };
});
